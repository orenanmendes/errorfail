export interface CreditAnalysis {
  name: string;
  cpf: string;
  birthDate: string;
  paymentDelay: number;
  monthlyIncome: number;
  fixedExpenses: number;
  outstandingDebts: number;
  purchaseHistory: number;
  jobTime: number;
  educationLevel: 'no_education' | 'elementary' | 'high_school' | 'undergraduate' | 'specialization' | 'masters' | 'doctorate';
  creditInquiries: number;
  ownsHome: boolean;
  maritalStatus: 'married' | 'single' | 'other';
  agentName: string;
  isRetired: boolean;
}

export interface ScoreBreakdown {
  creditCommitment: number;
  financialMargin: number;
  purchaseHistory: number;
  jobTime: number;
  educationLevel: number;
  creditInquiries: number;
  homeownership: number;
  maritalStatus: number;
  ageScore: number;
  retirementBonus: number;
  total: number;
}