import React, { useState } from 'react';
import { CreditAnalysis } from '../types';
import { Calculator } from 'lucide-react';

interface Props {
  onAnalyze: (data: CreditAnalysis) => void;
}

export default function CreditForm({ onAnalyze }: Props) {
  const [formData, setFormData] = useState<CreditAnalysis>({
    name: '',
    cpf: '',
    birthDate: '',
    paymentDelay: 0,
    monthlyIncome: 0,
    fixedExpenses: 0,
    outstandingDebts: 0,
    purchaseHistory: 0,
    jobTime: 0,
    educationLevel: 'high_school',
    creditInquiries: 0,
    ownsHome: false,
    maritalStatus: 'single',
    agentName: '',
    isRetired: false
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAnalyze(formData);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const value = e.target.type === 'checkbox' 
      ? (e.target as HTMLInputElement).checked
      : e.target.type === 'number' 
        ? Number(e.target.value)
        : e.target.value;

    setFormData(prev => ({
      ...prev,
      [e.target.name]: value
    }));
  };

  const formatCPF = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    return numbers.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/g, '$1.$2.$3-$4');
  };

  const handleCPFChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length <= 11) {
      setFormData(prev => ({
        ...prev,
        cpf: formatCPF(value)
      }));
    }
  };

  const inputClasses = "mt-2 block w-full px-4 py-3 rounded-lg border-2 border-gray-200 shadow-sm focus:border-[#457FF5] focus:ring focus:ring-[#457FF5] focus:ring-opacity-50 transition-all duration-200 text-lg";
  const labelClasses = "block text-sm font-semibold text-gray-700 mb-1";
  const sectionClasses = "bg-white p-6 rounded-xl shadow-lg mb-6";

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      <div className={sectionClasses}>
        <h3 className="text-xl font-semibold text-gray-800 mb-4">Informações do Agente</h3>
        <div className="grid grid-cols-1 gap-6">
          <div>
            <label className={labelClasses}>Nome do Agente</label>
            <input
              type="text"
              name="agentName"
              value={formData.agentName}
              onChange={handleChange}
              required
              className={inputClasses}
              placeholder="Digite o nome do agente"
            />
          </div>
        </div>
      </div>

      <div className={sectionClasses}>
        <h3 className="text-xl font-semibold text-gray-800 mb-4">Dados Pessoais</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="md:col-span-2">
            <label className={labelClasses}>Nome Completo</label>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              required
              className={inputClasses}
              placeholder="Digite o nome completo"
            />
          </div>

          <div>
            <label className={labelClasses}>CPF</label>
            <input
              type="text"
              name="cpf"
              value={formData.cpf}
              onChange={handleCPFChange}
              placeholder="000.000.000-00"
              required
              maxLength={14}
              className={inputClasses}
            />
          </div>

          <div>
            <label className={labelClasses}>Data de Nascimento</label>
            <input
              type="date"
              name="birthDate"
              value={formData.birthDate}
              onChange={handleChange}
              required
              className={inputClasses}
            />
          </div>

          <div className="flex items-center h-full">
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                name="isRetired"
                checked={formData.isRetired}
                onChange={handleChange}
                className="sr-only peer"
              />
              <div className="w-14 h-7 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:start-[4px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-6 after:w-6 after:transition-all peer-checked:bg-[#457FF5]"></div>
              <span className="ms-3 text-sm font-medium text-gray-700">Aposentado</span>
            </label>
          </div>
        </div>
      </div>

      <div className={sectionClasses}>
        <h3 className="text-xl font-semibold text-gray-800 mb-4">Informações Financeiras</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className={labelClasses}>Renda Mensal (R$)</label>
            <input
              type="number"
              name="monthlyIncome"
              value={formData.monthlyIncome}
              onChange={handleChange}
              required
              className={inputClasses}
              placeholder="0,00"
              min="0"
              step="0.01"
            />
          </div>

          <div>
            <label className={labelClasses}>Despesas Fixas (R$)</label>
            <input
              type="number"
              name="fixedExpenses"
              value={formData.fixedExpenses}
              onChange={handleChange}
              required
              className={inputClasses}
              placeholder="0,00"
              min="0"
              step="0.01"
            />
          </div>

          <div>
            <label className={labelClasses}>Dívidas Pendentes (R$)</label>
            <input
              type="number"
              name="outstandingDebts"
              value={formData.outstandingDebts}
              onChange={handleChange}
              required
              className={inputClasses}
              placeholder="0,00"
              min="0"
              step="0.01"
            />
          </div>

          <div>
            <label className={labelClasses}>Histórico de Compras (R$)</label>
            <input
              type="number"
              name="purchaseHistory"
              value={formData.purchaseHistory}
              onChange={handleChange}
              required
              className={inputClasses}
              placeholder="0,00"
              min="0"
              step="0.01"
            />
          </div>
        </div>
      </div>

      <div className={sectionClasses}>
        <h3 className="text-xl font-semibold text-gray-800 mb-4">Informações Adicionais</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className={labelClasses}>Atraso Médio em Pagamentos (dias)</label>
            <input
              type="number"
              name="paymentDelay"
              value={formData.paymentDelay}
              onChange={handleChange}
              required
              className={inputClasses}
              min="0"
              placeholder="0"
            />
          </div>

          <div>
            <label className={labelClasses}>Tempo no Emprego Atual (meses)</label>
            <input
              type="number"
              name="jobTime"
              value={formData.jobTime}
              onChange={handleChange}
              required
              className={inputClasses}
              min="0"
              placeholder="0"
            />
          </div>

          <div>
            <label className={labelClasses}>Nível de Escolaridade</label>
            <select
              name="educationLevel"
              value={formData.educationLevel}
              onChange={handleChange}
              required
              className={inputClasses}
            >
              <option value="no_education">Sem Escolaridade</option>
              <option value="elementary">Ensino Fundamental</option>
              <option value="high_school">Ensino Médio</option>
              <option value="undergraduate">Ensino Superior (Graduação)</option>
              <option value="specialization">Pós-Graduação</option>
              <option value="masters">Mestrado</option>
              <option value="doctorate">Doutorado</option>
            </select>
          </div>

          <div>
            <label className={labelClasses}>Estado Civil</label>
            <select
              name="maritalStatus"
              value={formData.maritalStatus}
              onChange={handleChange}
              required
              className={inputClasses}
            >
              <option value="single">Solteiro(a)</option>
              <option value="married">Casado(a)</option>
              <option value="other">Outro</option>
            </select>
          </div>

          <div>
            <label className={labelClasses}>Consultas de Crédito (últimos 6 meses)</label>
            <input
              type="number"
              name="creditInquiries"
              value={formData.creditInquiries}
              onChange={handleChange}
              required
              className={inputClasses}
              min="0"
              placeholder="0"
            />
          </div>

          <div className="flex items-center h-full">
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                name="ownsHome"
                checked={formData.ownsHome}
                onChange={handleChange}
                className="sr-only peer"
              />
              <div className="w-14 h-7 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:start-[4px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-6 after:w-6 after:transition-all peer-checked:bg-[#457FF5]"></div>
              <span className="ms-3 text-sm font-medium text-gray-700">Possui Casa Própria</span>
            </label>
          </div>
        </div>
      </div>

      <div className="flex justify-center pt-4">
        <button
          type="submit"
          className="inline-flex items-center px-8 py-4 text-lg font-semibold rounded-xl text-white bg-gradient-to-r from-[#457FF5] to-[#3567d4] hover:from-[#3567d4] hover:to-[#2d5abc] shadow-lg shadow-blue-500/50 transition-all duration-300 transform hover:scale-105"
        >
          <Calculator className="mr-3 h-6 w-6" />
          Analisar Crédito
        </button>
      </div>
    </form>
  );
}