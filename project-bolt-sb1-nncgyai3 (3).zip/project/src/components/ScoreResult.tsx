import React from 'react';
import { ScoreBreakdown } from '../types';
import { getScoreColor, getScoreMessage, calculateCreditSuggestion, scoreReferenceTable } from '../utils/calculateScore';
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from 'recharts';
import { Download } from 'lucide-react';
import { usePDF } from 'react-to-pdf';

interface Props {
  score: ScoreBreakdown;
  clientInfo: {
    name: string;
    cpf: string;
    fixedExpenses: number;
    agentName: string;
    isRetired: boolean;
  };
  monthlyIncome: number;
}

export default function ScoreResult({ score, clientInfo, monthlyIncome }: Props) {
  const { toPDF, targetRef } = usePDF({
    filename: `Dunome-${clientInfo.name.split(' ')[0]}-${new Date().toLocaleDateString('pt-BR').replace(/\//g, '-')}.pdf`,
    options: {
      format: [800, 1000],
      compress: true,
      quality: 0.3,
      scale: 0.7,
      dpi: 150,
      enableLinks: false,
      precision: 2
    }
  });

  const chartData = [
    { name: 'Compromisso de Crédito (25%)', value: score.creditCommitment, color: '#FF6B6B' },
    { name: 'Margem Financeira (20%)', value: score.financialMargin, color: '#4ECDC4' },
    { name: 'Histórico de Compras (10%)', value: score.purchaseHistory, color: '#45B7D1' },
    { name: 'Tempo de Emprego (10%)', value: score.jobTime, color: '#96CEB4' },
    { name: 'Nível Educacional (5%)', value: score.educationLevel, color: '#FFEEAD' },
    { name: 'Consultas de Crédito (10%)', value: score.creditInquiries, color: '#D4A5A5' },
    { name: 'Casa Própria (5%)', value: score.homeownership, color: '#9B5DE5' },
    { name: 'Estado Civil (5%)', value: score.maritalStatus, color: '#F15BB5' },
    { name: 'Idade (10%)', value: score.ageScore, color: '#00BBF9' },
    { name: 'Bônus Aposentadoria', value: score.retirementBonus, color: '#FFB86C' }
  ].filter(item => item.value !== 0);

  const formatCurrency = (value: number) => {
    return value.toLocaleString('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    });
  };

  const suggestedCredit = calculateCreditSuggestion(score.total, monthlyIncome);

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white/90 backdrop-blur-sm p-4 rounded-lg shadow-lg border border-gray-200">
          <p className="font-semibold">{payload[0].name}</p>
          <p className="text-[#457FF5]">{payload[0].value.toFixed(1)} pontos</p>
        </div>
      );
    }
    return null;
  };

  return (
    <div ref={targetRef} className="bg-gradient-to-br from-white to-gray-50 p-8 rounded-xl shadow-2xl max-w-4xl mx-auto">
      <div className="text-center mb-6">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Análise de Crédito</h1>
        <p className="text-gray-600">Dunome Calçados</p>
        <p className="text-gray-500 mt-2">Análise realizada por: {clientInfo.agentName}</p>
      </div>

      <div className="grid grid-cols-2 gap-6 mb-8 bg-white/80 backdrop-blur-sm p-6 rounded-xl shadow-lg">
        <div>
          <h3 className="text-lg font-semibold mb-4 text-gray-800">Dados do Cliente</h3>
          <div className="space-y-3">
            <div>
              <p className="text-sm text-gray-500">Nome</p>
              <p className="text-lg font-medium">{clientInfo.name}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">CPF</p>
              <p className="text-lg font-medium">{clientInfo.cpf}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Status</p>
              <p className="text-lg font-medium">{clientInfo.isRetired ? 'Aposentado' : 'Não Aposentado'}</p>
            </div>
          </div>
        </div>
        <div>
          <h3 className="text-lg font-semibold mb-4 text-gray-800">Informações Financeiras</h3>
          <div className="space-y-3">
            <div>
              <p className="text-sm text-gray-500">Renda Mensal</p>
              <p className="text-lg font-medium">{formatCurrency(monthlyIncome)}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Despesas Fixas</p>
              <p className="text-lg font-medium">{formatCurrency(clientInfo.fixedExpenses)}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-8 mb-8">
        <div className="bg-white/80 backdrop-blur-sm p-6 rounded-xl shadow-lg text-center">
          <div 
            className="inline-block p-8 rounded-full mb-4"
            style={{ 
              backgroundColor: `${getScoreColor(score.total)}20`,
              boxShadow: `0 0 30px ${getScoreColor(score.total)}40`
            }}
          >
            <div 
              className="text-6xl font-bold"
              style={{ color: getScoreColor(score.total) }}
            >
              {score.total.toFixed(1)}
            </div>
          </div>
          <div className="text-2xl font-semibold" style={{ color: getScoreColor(score.total) }}>
            {getScoreMessage(score.total)}
          </div>
        </div>

        <div className="bg-white/80 backdrop-blur-sm p-6 rounded-xl shadow-lg text-center">
          <h3 className="text-xl font-semibold mb-4">Sugestão de Crédito</h3>
          <p className="text-4xl font-bold text-[#457FF5] mb-2">{formatCurrency(suggestedCredit)}</p>
          <p className="text-sm text-gray-500">
            Valor sugerido com base no score e limite de 40% da renda mensal
          </p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-8 mb-8">
        <div className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={chartData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={90}
                paddingAngle={2}
                dataKey="value"
              >
                {chartData.map((entry, index) => (
                  <Cell 
                    key={`cell-${index}`} 
                    fill={entry.color}
                    style={{
                      filter: 'drop-shadow(0px 0px 8px rgba(255, 255, 255, 0.5))'
                    }}
                  />
                ))}
              </Pie>
              <Tooltip content={<CustomTooltip />} />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="grid grid-cols-2 gap-2 content-center">
          {chartData.map((item) => (
            <div 
              key={item.name} 
              className="p-2 rounded-lg"
              style={{ 
                backgroundColor: `${item.color}20`,
                borderLeft: `3px solid ${item.color}`
              }}
            >
              <div className="text-xs text-gray-600">{item.name}</div>
              <div className="text-sm font-semibold text-gray-900">
                {item.value.toFixed(1)} pts
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white/80 backdrop-blur-sm p-6 rounded-xl shadow-lg">
        <h3 className="text-xl font-semibold mb-4 text-center">Referência para um Bom Score</h3>
        <div className="overflow-hidden rounded-lg border border-gray-200">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Categoria</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Peso</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Descrição</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {scoreReferenceTable.map((item, index) => (
                <tr key={index} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                  <td className="px-4 py-2 text-sm text-gray-900">{item.category}</td>
                  <td className="px-4 py-2 text-sm text-gray-900">{item.weight}</td>
                  <td className="px-4 py-2 text-sm text-gray-900">{item.description}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="absolute top-8 right-8">
        <button
          onClick={() => toPDF()}
          className="inline-flex items-center px-4 py-2 rounded-lg text-white bg-gradient-to-r from-[#457FF5] to-[#3567d4] hover:from-[#3567d4] hover:to-[#2d5abc] shadow-lg shadow-blue-500/50 transition-all duration-300"
        >
          <Download className="mr-2 h-4 w-4" />
          Exportar PDF
        </button>
      </div>
    </div>
  );
}