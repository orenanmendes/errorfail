import React from 'react';
import { Info } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export default function ScoringManual({ isOpen, onClose }: Props) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-4xl max-h-[90vh] overflow-y-auto p-8 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-500 hover:text-gray-700"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>

        <h2 className="text-2xl font-bold text-gray-900 mb-6">Manual do Sistema de Pontuação</h2>

        <div className="space-y-6">
          <section>
            <h3 className="text-xl font-semibold text-[#457FF5] mb-3">1. Compromisso de Crédito (25%)</h3>
            <div className="bg-blue-50 p-4 rounded-lg">
              <p className="font-medium">Peso: 25 pontos máximos</p>
              <p>Baseado no atraso médio em pagamentos:</p>
              <ul className="list-disc ml-5 mt-2">
                <li>0 dias de atraso = 25 pontos</li>
                <li>Cada dia de atraso reduz a pontuação</li>
                <li>100 ou mais dias de atraso = 0 pontos</li>
              </ul>
            </div>
          </section>

          <section>
            <h3 className="text-xl font-semibold text-[#457FF5] mb-3">2. Margem Financeira (20%)</h3>
            <div className="bg-blue-50 p-4 rounded-lg">
              <p className="font-medium">Peso: 20 pontos máximos</p>
              <p>Cálculo: (Renda - (Despesas Fixas + Dívidas)) / Renda × 100</p>
              <ul className="list-disc ml-5 mt-2">
                <li>100% de margem = 20 pontos</li>
                <li>Pontuação proporcional à margem disponível</li>
              </ul>
            </div>
          </section>

          <section>
            <h3 className="text-xl font-semibold text-[#457FF5] mb-3">3. Histórico de Compras (10%)</h3>
            <div className="bg-blue-50 p-4 rounded-lg">
              <p className="font-medium">Peso: 10 pontos máximos</p>
              <p>Cálculo: Volume de compras / 10.000 × 100</p>
              <p>Pontuação proporcional ao histórico, máximo em R$ 10.000</p>
            </div>
          </section>

          <section>
            <h3 className="text-xl font-semibold text-[#457FF5] mb-3">4. Tempo de Emprego (10%)</h3>
            <div className="bg-blue-50 p-4 rounded-lg">
              <p className="font-medium">Peso: 10 pontos máximos</p>
              <ul className="list-disc ml-5 mt-2">
                <li>36 meses ou mais = 10 pontos</li>
                <li>Proporcional ao tempo de trabalho</li>
              </ul>
            </div>
          </section>

          <section>
            <h3 className="text-xl font-semibold text-[#457FF5] mb-3">5. Idade (10%)</h3>
            <div className="bg-blue-50 p-4 rounded-lg">
              <p className="font-medium">Peso: 10 pontos máximos</p>
              <ul className="list-disc ml-5 mt-2">
                <li>18-24 anos = 4 pontos</li>
                <li>25-34 anos = 8 pontos</li>
                <li>35-49 anos = 10 pontos (máximo)</li>
                <li>50-64 anos = 9 pontos</li>
                <li>65+ anos = 7 pontos</li>
              </ul>
            </div>
          </section>

          <section>
            <h3 className="text-xl font-semibold text-[#457FF5] mb-3">6. Consultas de Crédito (10% de penalidade)</h3>
            <div className="bg-blue-50 p-4 rounded-lg">
              <p className="font-medium">Peso: -10 pontos máximos (NEGATIVO)</p>
              <p>Cálculo: -(Número de consultas × 20)</p>
              <p>Cada consulta reduz 2 pontos do score total</p>
            </div>
          </section>

          <section>
            <h3 className="text-xl font-semibold text-[#457FF5] mb-3">7. Nível Educacional (5%)</h3>
            <div className="bg-blue-50 p-4 rounded-lg">
              <p className="font-medium">Peso: 5 pontos máximos</p>
              <ul className="list-disc ml-5 mt-2">
                <li>Sem Escolaridade = 1 ponto</li>
                <li>Ensino Fundamental = 1,5 pontos</li>
                <li>Ensino Médio = 2 pontos</li>
                <li>Graduação = 3 pontos</li>
                <li>Pós-Graduação = 3,5 pontos</li>
                <li>Mestrado = 4 pontos</li>
                <li>Doutorado = 5 pontos</li>
              </ul>
            </div>
          </section>

          <section>
            <h3 className="text-xl font-semibold text-[#457FF5] mb-3">8. Casa Própria (5%)</h3>
            <div className="bg-blue-50 p-4 rounded-lg">
              <p className="font-medium">Peso: 5 pontos máximos</p>
              <ul className="list-disc ml-5 mt-2">
                <li>Possui casa própria = 5 pontos</li>
                <li>Não possui = 0 pontos</li>
              </ul>
            </div>
          </section>

          <section>
            <h3 className="text-xl font-semibold text-[#457FF5] mb-3">9. Estado Civil (5%)</h3>
            <div className="bg-blue-50 p-4 rounded-lg">
              <p className="font-medium">Peso: 5 pontos máximos</p>
              <ul className="list-disc ml-5 mt-2">
                <li>Casado(a) = 2,5 pontos</li>
                <li>Solteiro(a)/Outro = 1 ponto</li>
              </ul>
            </div>
          </section>

          <section>
            <h3 className="text-xl font-semibold text-[#457FF5] mb-3">10. Bônus Aposentadoria</h3>
            <div className="bg-blue-50 p-4 rounded-lg">
              <p className="font-medium">Bônus adicional: 10 pontos</p>
              <ul className="list-disc ml-5 mt-2">
                <li>Cliente aposentado = +10 pontos extras</li>
                <li>Não aposentado = 0 pontos</li>
              </ul>
              <p className="mt-2 text-sm text-gray-600">Este bônus reconhece a estabilidade de renda dos aposentados.</p>
            </div>
          </section>

          <section>
            <h3 className="text-xl font-semibold text-[#457FF5] mb-3">Cálculo do Crédito Sugerido</h3>
            <div className="bg-blue-50 p-4 rounded-lg">
              <p>O valor do crédito é calculado com base no score final e limitado a 40% da renda mensal:</p>
              <ul className="list-disc ml-5 mt-2">
                <li>Score &ge; 80: 100% do limite (40% da renda)</li>
                <li>Score &ge; 60: 70% do limite</li>
                <li>Score &ge; 40: 40% do limite</li>
                <li>Score &lt; 40: 20% do limite</li>
              </ul>
            </div>
          </section>

          <section>
            <h3 className="text-xl font-semibold text-[#457FF5] mb-3">Score Final</h3>
            <div className="bg-blue-50 p-4 rounded-lg">
              <ul className="list-disc ml-5">
                <li>Excelente: 80-100 pontos</li>
                <li>Bom: 60-79 pontos</li>
                <li>Regular: 40-59 pontos</li>
                <li>Ruim: 0-39 pontos</li>
              </ul>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}