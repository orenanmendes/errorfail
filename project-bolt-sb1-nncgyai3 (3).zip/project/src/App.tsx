import React, { useState } from 'react';
import { CreditAnalysis, ScoreBreakdown } from './types';
import CreditForm from './components/CreditForm';
import ScoreResult from './components/ScoreResult';
import ScoringManual from './components/ScoringManual';
import { calculateScore } from './utils/calculateScore';
import { ShoppingBag, Info } from 'lucide-react';

function App() {
  const [score, setScore] = useState<ScoreBreakdown | null>(null);
  const [clientInfo, setClientInfo] = useState<{
    name: string;
    cpf: string;
    fixedExpenses: number;
    agentName: string;
    isRetired: boolean;
  } | null>(null);
  const [monthlyIncome, setMonthlyIncome] = useState<number>(0);
  const [isManualOpen, setIsManualOpen] = useState(false);

  const handleAnalyze = (data: CreditAnalysis) => {
    const result = calculateScore(data);
    setScore(result);
    setClientInfo({
      name: data.name,
      cpf: data.cpf,
      fixedExpenses: data.fixedExpenses,
      agentName: data.agentName,
      isRetired: data.isRetired
    });
    setMonthlyIncome(data.monthlyIncome);
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-[#457FF5] text-white py-6 shadow-lg">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-center">
            <ShoppingBag className="h-8 w-8 mr-3" />
            <h1 className="text-3xl font-bold">Dunome Calçados</h1>
          </div>
          <p className="text-center mt-2 text-blue-100">Sistema de Análise de Crédito</p>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {!score ? (
            <div className="bg-white rounded-lg shadow-lg p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Análise de Crédito</h2>
              <CreditForm onAnalyze={handleAnalyze} />
            </div>
          ) : (
            <ScoreResult 
              score={score} 
              clientInfo={clientInfo!} 
              monthlyIncome={monthlyIncome}
            />
          )}
        </div>
      </main>

      <footer className="bg-gray-800 text-white py-4 mt-8">
        <div className="container mx-auto px-4 text-center">
          <p>&copy; 2025 Dunome Calçados. Todos os direitos reservados.</p>
        </div>
      </footer>

      <button
        onClick={() => setIsManualOpen(true)}
        className="fixed bottom-6 right-6 bg-[#457FF5] text-white p-3 rounded-full shadow-lg hover:bg-[#3567d4] transition-colors duration-200 group"
        title="Manual do Sistema de Pontuação"
      >
        <Info className="h-6 w-6" />
        <span className="absolute right-full mr-3 bg-white text-gray-800 px-2 py-1 rounded text-sm whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity duration-200 shadow-lg">
          Manual do Sistema de Pontuação
          <br />
          <span className="text-[#457FF5] font-semibold">Bônus Aposentado: +10 pontos!</span>
        </span>
      </button>

      <ScoringManual isOpen={isManualOpen} onClose={() => setIsManualOpen(false)} />
    </div>
  );
}

export default App;