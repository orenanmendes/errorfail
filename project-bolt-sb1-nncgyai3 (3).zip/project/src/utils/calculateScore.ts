import { CreditAnalysis, ScoreBreakdown } from '../types';

function calculateAge(birthDate: string): number {
  const today = new Date();
  const birth = new Date(birthDate);
  let age = today.getFullYear() - birth.getFullYear();
  const monthDiff = today.getMonth() - birth.getMonth();
  
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
    age--;
  }
  
  return age;
}

export function calculateScore(data: CreditAnalysis): ScoreBreakdown {
  // Credit Commitment (25%)
  const creditCommitment = Math.max(0, 100 - Math.min(data.paymentDelay, 100));
  
  // Financial Margin (20%)
  const financialMargin = Math.min(100, ((data.monthlyIncome - (data.fixedExpenses + data.outstandingDebts)) / data.monthlyIncome) * 100);
  
  // Purchase History (10%)
  const purchaseHistoryScore = Math.min(100, (data.purchaseHistory / 10000) * 100);
  
  // Job Time (10%)
  const jobTimeScore = Math.min(100, (data.jobTime / 36) * 100);
  
  // Education Level (5%)
  const educationPoints = {
    no_education: 20,
    elementary: 30,
    high_school: 40,
    undergraduate: 60,
    specialization: 70,
    masters: 80,
    doctorate: 100
  }[data.educationLevel];
  
  // Credit Inquiries (10% penalty) - Agora retorna valor negativo
  const inquiriesPenalty = -(Math.min(100, data.creditInquiries * 20));
  
  // Homeownership (5%)
  const homeownershipPoints = data.ownsHome ? 100 : 0;
  
  // Marital Status (5%)
  const maritalBonus = data.maritalStatus === 'married' ? 50 : 20;

  // Age Score (10%)
  const age = calculateAge(data.birthDate);
  let ageScore = 0;
  if (age >= 18 && age < 25) ageScore = 40;
  else if (age >= 25 && age < 35) ageScore = 80;
  else if (age >= 35 && age < 50) ageScore = 100;
  else if (age >= 50 && age < 65) ageScore = 90;
  else ageScore = 70;

  // Retirement Bonus (additional points for retirees)
  const retirementBonus = data.isRetired ? 10 : 0;

  const breakdown: ScoreBreakdown = {
    creditCommitment: creditCommitment * 0.25,
    financialMargin: financialMargin * 0.20,
    purchaseHistory: purchaseHistoryScore * 0.10,
    jobTime: jobTimeScore * 0.10,
    educationLevel: educationPoints * 0.05,
    creditInquiries: inquiriesPenalty * 0.10,
    homeownership: homeownershipPoints * 0.05,
    maritalStatus: maritalBonus * 0.05,
    ageScore: ageScore * 0.10,
    retirementBonus: retirementBonus,
    total: 0
  };

  breakdown.total = Object.values(breakdown).reduce((acc, val) => acc + val, 0) - breakdown.total;
  
  return breakdown;
}

export function calculateCreditSuggestion(score: number, monthlyIncome: number): number {
  // Base: até 40% da renda mensal
  const maxCredit = monthlyIncome * 0.4;
  
  // Fator multiplicador baseado no score
  let scoreFactor = 0;
  
  if (score >= 80) {
    scoreFactor = 1.0; // 100% do limite máximo
  } else if (score >= 60) {
    scoreFactor = 0.7; // 70% do limite máximo
  } else if (score >= 40) {
    scoreFactor = 0.4; // 40% do limite máximo
  } else {
    scoreFactor = 0.2; // 20% do limite máximo
  }

  return maxCredit * scoreFactor;
}

export function getScoreColor(score: number): string {
  if (score >= 80) return '#22c55e';
  if (score >= 60) return '#eab308';
  return '#ef4444';
}

export function getScoreMessage(score: number): string {
  if (score >= 80) return 'Excelente';
  if (score >= 60) return 'Bom';
  if (score >= 40) return 'Regular';
  return 'Ruim';
}

export const scoreReferenceTable = [
  {
    category: 'Compromisso de Crédito',
    weight: '25%',
    description: 'Histórico de pagamentos em dia'
  },
  {
    category: 'Margem Financeira',
    weight: '20%',
    description: 'Relação entre renda e despesas'
  },
  {
    category: 'Histórico de Compras',
    weight: '10%',
    description: 'Volume de compras realizadas'
  },
  {
    category: 'Tempo de Emprego',
    weight: '10%',
    description: 'Estabilidade profissional'
  },
  {
    category: 'Idade',
    weight: '10%',
    description: 'Faixa etária do cliente'
  },
  {
    category: 'Consultas de Crédito',
    weight: '10%',
    description: 'Impacto negativo por consultas'
  },
  {
    category: 'Nível Educacional',
    weight: '5%',
    description: 'Grau de escolaridade'
  },
  {
    category: 'Casa Própria',
    weight: '5%',
    description: 'Possui imóvel próprio'
  },
  {
    category: 'Estado Civil',
    weight: '5%',
    description: 'Situação civil atual'
  }
];